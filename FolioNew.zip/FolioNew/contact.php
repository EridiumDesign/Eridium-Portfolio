
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Hello, I'm Tiago Santos. I'm a student and Freelance Web Designer/Developer based in Kolding, DK. I also have skills in branding, graphics design, logos...">
    <meta name="author" content="Tiago Santos">
    <link rel="icon" href="icon.ico">

    <title>Eridium Design</title>
    <link rel="shortcut icon" href="icon.ico" >

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/custom.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">

    <!--Font Awesome -->
    <script src="https://use.fontawesome.com/cbb0bb2946.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><img src="img/logo.png" width="20" heigth="20"></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php">HOME</a></li>
            <li><a href="about.php">ABOUT</a></li>
            <li class="active"><a href="contact.php">CONTACT</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <!-- Quote -->

    <div class="container mt1">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <h1 class="center cita" style="font-style:normal;">DO YOU HAVE A PROJECT IN MIND? SOMETHING I MIGHT BE ABLE TO <span>HELP</span> WITH? LET'S TALK.</h1>
            </div>
        </div>
    </div>

    <!-- Contact Info -->

    <div class="container" style="border-bottom:1px solid #dadada;">
        <div class="row">
            <div class="col-md-6">
                <h2 class="section-title" style="margin-bottom:10px;margin-top:0px;">Get in touch</h2>
                <p class="about-text" style="margin-bottom:20px;">I'm currently available for freelance projects and internships. If you're interested in working with me, just send me a message. Or maybe you just want to say hi, ask a question, tell a joke? I love getting mail from folks like you!</p>
            </div>
            <div class="col-md-3">
                <h2 class="section-title" style="margin-bottom:10px;margin-top:0px;">Where to find me</h2>
                <p class="about-text"><strong>Kolding</strong>, Denmark</p>
                <a href="mailto:hellootiago@gmail.com" class="about-text" style="color: #f39c12;">hellootiago@gmail.com</a>
                <h3 class="section-title" style="margin:20px 0 10px 0;">Social Media</h3>
                <div class="social-contact">
                <a href="https://www.facebook.com/eridiumdesigns/?fref=ts" target="_blank" class="menu-social"><i class="fa fa-facebook-official fa-lg" aria-hidden="true"></i></a>
                <a href="https://instagram.com/tuganadina" target="_blank" class="menu-social"><i class="fa fa-instagram fa-lg" aria-hidden="true"></i></a>
                <a href="https://www.behance.net/EridiumDzn" target="_blank" class="menu-social"><i class="fa fa-behance fa-lg" aria-hidden="true"></i></a>
            </div>
            </div>
            <div class="col-md-3">
                <img src="img/handshake.png" width="129" heigth="206" class="pull-right">
            </div>
        </div>
    </div>

<?php include ('folio.php');?>
<?php include ('footer.php');?>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script type="text/javascript" src="js/jquery.mixitup.min.js"></script>

    <script type="text/javascript" src="js/main.js"></script>
    
    <script type="text/javascript">
    $(function () {
        
        var filterList = {
        
            init: function () {
            
                // MixItUp plugin
                // http://mixitup.io
                $('#portfoliolist').mixItUp({
                selectors: {
                  target: '.portfolio',
                  filter: '.filter' 
                    }  
                });                             
            
            }

        };
        
        // Run the show!
        filterList.init();
        
        
    }); 
    </script>

    <script src="js/bootstrap.min.js"></script>
    
  </body>
</html>
