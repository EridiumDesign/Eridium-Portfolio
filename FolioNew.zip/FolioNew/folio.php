<?php
	echo '<div class="container">

        <h2 class="section-title">My Portfolio</h2>

        <ul id="filters" class="clearfix">
            <li><span class="filter active2" data-filter=".all, .brand, .graph, .logo, .web">All</span></li>
            <li><span class="filter" data-filter=".web">Web</span></li>
            <li><span class="filter" data-filter=".logo">Logo</span></li>
            <li><span class="filter" data-filter=".brand">Branding</span></li>
            <li><span class="filter" data-filter=".graph">Graphics</span></li>
        </ul>

        <div id="portfoliolist">
            
            <a href="p1.php"><div class="portfolio logo" data-cat="logo">
                <div class="portfolio-wrapper">             
                    <img src="img/portfolios/1.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p1.php">Eridium Lettering</a>
                            <span class="text-category">Logo</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>           

            <a href="p2.php"><div class="portfolio brand" data-cat="brand">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/2.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p2.php">Eridium Branding</a>
                            <span class="text-category">Branding</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>    
            
            <a href="p3.php"><div class="portfolio brand" data-cat="brand">
                <div class="portfolio-wrapper">                     
                    <img src="img/portfolios/3.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p3.php">SmartSec</a>
                            <span class="text-category">Branding</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>            
            
            <a href="p4.php"><div class="portfolio web" data-cat="web">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/4.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p4.php">Food Patrol</a>
                            <span class="text-category">Web</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>
                        
            <a href="p5.php"><div class="portfolio web" data-cat="web">
                <div class="portfolio-wrapper">
                    <img src="img/portfolios/5.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p5.php">Wexplore</a>
                            <span class="text-category">Web</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>      
            
            <a href="p6.php"><div class="portfolio brand" data-cat="brand">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/6.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p6.php">Eridium Intro</a>
                            <span class="text-category">Branding</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>
            
            <a href="p7.php"><div class="portfolio graph" data-cat="graph">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/7.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p7.php">Kitz Background</a>
                            <span class="text-category">Graphics</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>
            
            <a href="p8.php"><div class="portfolio graph" data-cat="graph">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/8.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p8.php">Pig Background</a>
                            <span class="text-category">Graphics</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>
            
            <a href="p9.php"><div class="portfolio logo" data-cat="logo">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/9.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title"href="p9.php">Product Eaze</a>
                            <span class="text-category">Logo</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>                                                  
            
            <a href="p10.php"><div class="portfolio graph" data-cat="graph">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/10.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p10.php">Pavelation Background</a>
                            <span class="text-category">Graphics</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>           

            <a href="p11.php"><div class="portfolio graph" data-cat="graph">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/11.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p11.php">Kill Bill Poster</a>
                            <span class="text-category">Graphics</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>                                                                

            <a href="p12.php"><div class="portfolio web" data-cat="web">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/12.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p12.php">AppAcademy</a>
                            <span class="text-category">Web</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>                                              
            
            <a href="p13.php"><div class="portfolio web" data-cat="web">
                <div class="portfolio-wrapper">         
                    <img src="img/portfolios/13.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p13.php">Dash Wallet</a>
                            <span class="text-category">Web</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>                      

            <a href="p14.php"><div class="portfolio graph" data-cat="graph">
                <div class="portfolio-wrapper">                     
                    <img src="img/portfolios/14.jpg" alt="" />
                    <div class="label">
                        <div class="label-text">
                            <a class="text-title" href="p14.php">Steve Jobs</a>
                            <span class="text-category">Graphics</span>
                        </div>
                        <div class="label-bg"></div>
                    </div>
                </div>
            </div></a>                   
            
        </div>
        
    </div><!-- container -->';
?>