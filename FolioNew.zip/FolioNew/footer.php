<?php
	echo '<div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="gototop"><a href="#" id="gtt"><span>Go to top!</span></a></h2>
                <div class="head"><img src="img/head.png"></div>
            </div>
        </div>
    </div>

    <div id="footer">
        <div class="container">
            <p class="text-muted credit">Tiago Santos. All rights reserved 2016.</p>
            <div class="social-cont">
                <a href="https://www.facebook.com/eridiumdesigns/?fref=ts" target="_blank" class="menu-social"><i class="fa fa-facebook-official fa-lg" aria-hidden="true"></i></a>
                <a href="https://instagram.com/tuganadina" target="_blank" class="menu-social"><i class="fa fa-instagram fa-lg" aria-hidden="true"></i></a>
                <a href="https://www.behance.net/EridiumDzn" target="_blank" class="menu-social"><i class="fa fa-behance fa-lg" aria-hidden="true"></i></a>
                <a href="https://github.com/EridiumDesign" target="_blank" class="menu-social"><i class="fa fa-github fa-lg" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>';
?>