<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Hello, I'm Tiago Santos. I'm a student and Freelance Web Designer/Developer based in Kolding, DK. I also have skills in branding, graphic design, logos...">
    <meta name="author" content="Tiago Santos">
    <link rel="icon" href="icon.ico">

    <title>Eridium Design</title>
    <link rel="shortcut icon" href="icon.ico" >

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/custom.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">

    <!--Font Awesome -->
    <script src="https://use.fontawesome.com/cbb0bb2946.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><img src="img/logo.png" width="20" heigth="20"></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php">HOME</a></li>
            <li class="active"><a href="about.php">ABOUT</a></li>
            <li><a href="contact.php">CONTACT</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="mehello"><img src="img/hello.png"></div>

    <!-- Quote -->

    <div class="container mt1">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <h1 class="center cita">"WHAT MAKES <span>DESIGN</span> GREAT NEVER CHANGES"</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <h1 class="pull-right mfix2" style="color:#565758;">-SUSAN KARE</h1>
            </div>
        </div>
    </div>

    <!-- About pic and text -->

    <div class="container mt2">
        <div class="row">
            <div class="col-md-6"><img width="300" heigth="400" src="img/mypic.jpg" class="mypic"></div>
            <div class="col-md-6 about-text mfix"><p>Hello again ! I’m Tiago Santos, a 19 year old from Portugal. I started working is this field back in 2010 when I was still in the 9th grade and just started messing around with Photoshop. I was fascinated by what people could do with these softwares, which lead me to follow it as a career. My dream is to be a successful designer and for the past 6 years I’ve been working hard to accomplish this goal.</p><p>From 2011 to 2014 I studied Multimedia at Instituto das Artes e da Imagem and recently finished my AP Degree in Multimedia Design and Communication. Currently, I’m taking a Top-Up in Web Development at the International Business Academy in Kolding, Denmark.</p><p>Until now, all the projects I’ve worked on, were individual or the teams I had weren’t that serious. But one thing I’m sure, is that I’m capable of adapting to different environments and work really well with others.</p></div>
        </div>
    </div>

    <!-- Skills -->

    <div class="container" style="border-bottom:1px solid #dadada;padding-bottom:20px;">
        <h2 class="section-title">What I can do</h2>

        <div class="row">
            <div class="col-md-6">
                <div class="skill-label">HTML <span>I'm awesome here</span></div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 90%;">
                        <span class="sr-only">90% Complete</span>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="skill-label">CSS <span>I'm awesome here</span></div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 90%;">
                        <span class="sr-only">90% Complete</span>
                    </div>
                </div>
            </div>
        </div><!--end row-->

        <div class="row">
            <div class="col-md-6">
                <div class="skill-label">JavaScript <span>On the way to awesomeness</span></div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">
                        <span class="sr-only">40% Complete</span>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="skill-label">Photoshop <span>I'm pretty good here</span></div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 70%;">
                        <span class="sr-only">70% Complete</span>
                    </div>
                </div>
            </div>
        </div><!--end row-->

        <div class="row">
            <div class="col-md-6">
                <div class="skill-label">Bootstrap <span>I'm awesome here</span></div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 80%;">
                        <span class="sr-only">80% Complete</span>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="skill-label">WordPress <span>I'm pretty good here</span></div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 70%;">
                        <span class="sr-only">70% Complete</span>
                    </div>
                </div>
            </div>
        </div><!--end row-->

    </div>

    <!-- Education -->

    <div class="container" style="border-bottom:1px solid #dadada;padding-bottom:20px;">
        <div class="row">

            <div class="col-md-6">
                <h2 class="section-title">Experience</h2>
                <ul class="exed-list">
                    <li><span>Real Experiência</span> - Front-End Developer, Feb 2014 - May 2014</li>
                    <li><span>ESN Kolding</span> - Designer and Vice-President, Dec 2014 - Dec 2015</li>
                    <li><span>WeXplore</span> - Front-End Developer, Jan 2015 - Apr 2015</li>
                    <li><span>EU Ambassador at EXPO Milan'15</span> - Volunteer, Jul 2015</li>
                </ul>
            </div>

            <div class="col-md-6">
                <h2 class="section-title">Education</h2>
                <ul class="exed-list">
                    <li><span>Colégio Liceal de Santa Maria de Lamas</span> - 2006 - 2011</li>
                    <li><span>Instituto das Artes e da Imagem</span> - Multimedia, 2011 - 2014</li>
                    <li><span>International Business Academy</span> - AP Degree in Multimedia Design, 2014 - 2016</li>
                    <li><span>International Business Academy</span> - Top-Up in Front-End Web Development, 2016 - Present</li>
                </ul>
            </div>

        </div>
    </div>

<?php include ('folio.php');?>
<?php include ('footer.php');?>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script type="text/javascript" src="js/jquery.mixitup.min.js"></script>

    <script type="text/javascript" src="js/main.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {

            $(document).ready(function() {
                $('.mehello').animate({
                'marginLeft' : "130px" //moves left
                });
            });
    
        });
    </script>
    
    <script type="text/javascript">
    $(function () {
        
        var filterList = {
        
            init: function () {
            
                // MixItUp plugin
                // http://mixitup.io
                $('#portfoliolist').mixItUp({
                selectors: {
                  target: '.portfolio',
                  filter: '.filter' 
                    }  
                });                             
            
            }

        };
        
        // Run the show!
        filterList.init();
        
        
    }); 
    </script>

    
    <script src="js/bootstrap.min.js"></script>

  </body>
</html>
