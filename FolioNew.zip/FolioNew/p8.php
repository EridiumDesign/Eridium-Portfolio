<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="author" content="Tiago Santos">
    <link rel="icon" href="icon.ico">

    <title>Eridium Design</title>
    <link rel="shortcut icon" href="icon.ico" >

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/custom.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
    
    <!--Font Awesome -->
    <script src="https://use.fontawesome.com/cbb0bb2946.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

<?php include ('header.php');?>

    <div class="container mt3">

    <h2 class="section-title">Pig Background <a href="p9.php" class="next-proj">Next Project</a></h2>

    </div>

    <div class="container-fluid" id="main-content">
        <div class="row">
            <div class="col-md-5 col-xs-11" style="padding-right: 1px;padding-left: 0px;">
                <img src="img/show/p8.jpg" width="900" height="440" class="img-responsive">
            </div>
            <div class="col-md-5 col-xs-11" style="padding-right: 1px;padding-left: 1px;">
                <img src="img/show/p8_2.jpg" width="900" height="440" class="img-responsive">
            </div>
            <div class="col-md-5 col-xs-11" style="padding-right: 0px;padding-left: 1px;">
                <img src="img/show/p8_3.jpg" width="900" height="440" class="img-responsive">
            </div>
        </div>
        <!-- /.row -->
    </div>

    <div class="container" style="border-bottom:1px solid #dadada;padding-bottom:20px;">
        <div class="row">
            <div class="col-md-6">
                <h2 class="section-title">Description</h2>
                <p class="about-text">This was a background I made 6 years ago, when the old youtube layout was in use. This project turned out better than what I expected. The person who requested really liked flames, so he asked me to put some, and on top of that I saw a chance of showing some chaos and destruction, so I cracked the letters to give it the final look.</p>
            </div>
            <div class="col-md-6">
                <h2 class="section-title">Tools</h2>
                <ul class="exed-list">
                    <li class="about-text">Adobe Illustrator</li>
                    <li class="about-text">Adobe Photoshop</li>
                    <li class="about-text">Cinema 4D</li>
                </ul>
            </div>
        </div>
    </div>

<?php include ('folio.php');?>
<?php include ('footer.php');?>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script type="text/javascript" src="js/jquery.mixitup.min.js"></script>

    <script type="text/javascript" src="js/main.js"></script>
    
    <script type="text/javascript">
    $(function () {
        
        var filterList = {
        
            init: function () {
            
                // MixItUp plugin
                // http://mixitup.io
                $('#portfoliolist').mixItUp({
                selectors: {
                  target: '.portfolio',
                  filter: '.filter' 
                    }  
                });                             
            
            }

        };
        
        // Run the show!
        filterList.init();
        
        
    }); 
    </script>


    <script src="js/bootstrap.min.js"></script>

  </body>
</html>
