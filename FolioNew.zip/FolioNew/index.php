<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Hello, I'm Tiago Santos. I'm a student and Freelance Web Designer/Developer based in Kolding, DK. I also have skills in branding, graphics design, logos...">
<meta name="author" content="Tiago Santos">
<link rel="icon" href="icon.ico">
<title>Eridium Design</title>
<link rel="shortcut icon" href="icon.ico">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/custom.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<script src="https://use.fontawesome.com/cbb0bb2946.js"></script>
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php"><img src="img/logo.png" width="20" heigth="20"></a>
</div>
<div id="navbar" class="collapse navbar-collapse">
<ul class="nav navbar-nav navbar-right">
<li class="active"><a href="index.php">HOME</a></li>
<li><a href="about.php">ABOUT</a></li>
<li><a href="contact.php">CONTACT</a></li>
</ul>
</div><!--/.nav-collapse -->
</div>
</nav>
<div class="container-fluid jumbo-edit mtPhp">
<div class="container">
<div class="row">
<div class="col-md-12 col-sm-12">
<div class="pull-left">
<p class="jumbo-title">HELLO, I'M TIAGO SANTOS</p>
<p class="jumbo-subtitle">A 19 year old student who wants to be a designer.</p>
<p class="jumbo-subsubtitle">DESIGN&nbsp;&#8226;&nbsp;FRONT-END DEVELOPMENT&nbsp;&#8226;&nbsp;PERSON</p>
<div class="goku"><img src="img/goku.gif"></div>
</div>
<picture>
<source media="(min-width: 992px)" srcset="img/desk.png" class="img-responsive pull-right">
<source media="(max-width: 768px)" srcset="img/desk2.png" class="img-responsive pull-right">
<img src="img/desk.png" alt="a cute kitten" class="img-responsive pull-right">
</picture>
</div>
</div>
</div>
</div>
<?php include ('folio.php');?>
<?php include ('footer.php');?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/jquery.mixitup.min.js"></script>
<script src="js/main.js"></script>
<script>$(function(){var filterList={init:function(){$('#portfoliolist').mixItUp({selectors:{target:'.portfolio',filter:'.filter'}});}};filterList.init();});</script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
